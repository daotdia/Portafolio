module.exports = {
    plugins: [
      require('autoprefixer'),
      require('tailwindcss')
    ]
  }